package loop;

public class Loops {

	public static void main(String[] args) {
		
		int i=1;
		while(i<=30);
		{
			System.out.println(i);
			i=i+1;
			if(i<=30); {
				System.out.println("correct");
			}
		}
		System.out.println("valid");
	}

}
